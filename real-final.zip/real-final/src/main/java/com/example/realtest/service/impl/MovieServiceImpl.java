package com.example.realtest.service.impl;

import com.example.realtest.dto.MovieRequest;
import com.example.realtest.dto.MovieResponse;
import com.example.realtest.entity.Movie;
import com.example.realtest.exception.MovieNotFoundException;
import com.example.realtest.mapper.MovieMapper;
import com.example.realtest.repo.MovieRepo;
import com.example.realtest.service.MovieService;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
// ✅ Class-level: all methods default to read-only
// - Hibernate skips dirty checking (no entity change tracking)
// - Flush mode set to NEVER (no accidental writes)
// - Better performance for all SELECT operations
public class MovieServiceImpl implements MovieService {

    private final MovieRepo movieRepo;
    private final MovieMapper movieMapper;

    // =========================================================
    // WRITE OPERATIONS — override class-level with full transaction
    // + evict stale cache entries on every mutation
    // =========================================================

    @Override
    @Transactional(
        propagation = Propagation.REQUIRED,
        // ✅ REQUIRED: reuse existing transaction if called from another
        //    transactional method, otherwise start a new one.

        isolation = Isolation.READ_COMMITTED
        // ✅ READ_COMMITTED: only reads committed data from other transactions.
        //    Prevents dirty reads. Standard choice for write operations.
    )
    @Caching(evict = {
        @CacheEvict(value = "movies", allEntries = true),
        // ✅ Evict full list cache — new movie makes the cached list stale.

        @CacheEvict(value = "moviesByGenre", allEntries = true),
        // ✅ Evict genre cache — new movie may belong to a cached genre.

        @CacheEvict(value = "moviesByDirector", allEntries = true)
        // ✅ Evict director cache — new movie may belong to a cached director.
    })
    public MovieResponse createMovie(MovieRequest request) {
        // Maps request DTO → Movie entity, then persists to DB
        Movie movie = movieMapper.toEntity(request);
        return movieMapper.toResponse(movieRepo.save(movie));
        // 🔁 If save() throws any RuntimeException → full rollback
        // 🗑️ Cache eviction happens only after successful commit
    }

    @Override
    @Transactional(
        propagation = Propagation.REQUIRED,
        // ✅ REQUIRED: joins existing transaction or creates a new one.
        //    All changes roll back together if anything fails.

        isolation = Isolation.READ_COMMITTED
        // ✅ READ_COMMITTED: only sees committed data during the fetch.
        //    Non-repeatable reads acceptable since we overwrite fields anyway.
    )
    @Caching(
        put = {
            @CachePut(value = "movie", key = "#id")
            // ✅ CachePut: updates "movie" cache with the new state after update.
            //    Next findById(id) call returns from cache, not DB.
        },
        evict = {
            @CacheEvict(value = "movies", allEntries = true),
            // ✅ Evict full list cache — updated movie changes list results.

            @CacheEvict(value = "moviesByGenre", allEntries = true),
            // ✅ Evict genre cache — genre may have changed after update.

            @CacheEvict(value = "moviesByDirector", allEntries = true)
            // ✅ Evict director cache — director may have changed after update.
        }
    )
    public MovieResponse updateMovie(Long id, MovieRequest request) {
        // Step 1: fetch existing entity — throws 404 if not found
        Movie existing = movieRepo.findById(id)
                .orElseThrow(() -> new MovieNotFoundException(id));

        // Step 2: apply changes (Hibernate dirty checking will detect these)
        existing.setTitle(request.getTitle());
        existing.setDirector(request.getDirector());
        existing.setGenere(request.getGenere());
        existing.setReleaseYear(request.getReleaseYear());
        existing.setRating(request.getRating());

        // Step 3: save and return updated response
        return movieMapper.toResponse(movieRepo.save(existing));
        // 🔁 If save() throws any RuntimeException → full rollback
        // 🗑️ Cache eviction + update happens only after successful commit
    }

    @Override
    @Transactional(
        propagation = Propagation.REQUIRED,
        // ✅ REQUIRED: delete must always run in a transaction.

        isolation = Isolation.READ_COMMITTED
        // ✅ READ_COMMITTED: existsById and deleteById run in same transaction.
    )
    @Caching(evict = {
        @CacheEvict(value = "movie", key = "#id"),
        // ✅ Evict specific movie entry — it no longer exists.

        @CacheEvict(value = "movies", allEntries = true),
        // ✅ Evict full list cache — deleted movie must not appear in lists.

        @CacheEvict(value = "moviesByGenre", allEntries = true),
        // ✅ Evict genre cache — deleted movie may have been in a cached genre.

        @CacheEvict(value = "moviesByDirector", allEntries = true)
        // ✅ Evict director cache — deleted movie may have been in a cached director.
    })
    public void deleteMovie(Long id) {
        // Step 1: guard check — throws 404 instead of silent no-op
        if (!movieRepo.existsById(id)) {
            throw new MovieNotFoundException(id);
        }
        // Step 2: delete — rolls back automatically if exception occurs
        movieRepo.deleteById(id);
        // 🔁 If deleteById() throws any RuntimeException → full rollback
        // 🗑️ Cache eviction happens only after successful commit
    }

    // =========================================================
    // JPA DERIVED QUERY METHODS — read-only (inherited)
    // Method names parsed by Spring Data to auto-generate queries
    // =========================================================

    @Override
    @Cacheable(value = "movies")
    // ✅ First call hits DB → stores result in "movies" cache (ConcurrentHashMap)
    // ✅ Subsequent calls return from cache without hitting DB
    public List<MovieResponse> findAll() {
        return movieRepo.findAll()
                .stream()
                .map(movieMapper::toResponse)
                .toList();
    }

    @Override
    @Cacheable(value = "movie", key = "#id")
    // ✅ Cache key is the movie ID — each movie cached separately.
    // ✅ throws MovieNotFoundException (404) if not found.
    public MovieResponse findById(Long id) {
        Movie movie = movieRepo.findById(id)
                .orElseThrow(() -> new MovieNotFoundException(id));
        return movieMapper.toResponse(movie);
    }

    @Override
    @Cacheable(value = "movies", key = "#page + '-' + #size + '-' + #sortBy + '-' + #direction")
    // ✅ Composite key: each unique page/size/sort combination cached separately.
    //    e.g. "0-10-title-asc" and "1-10-rating-desc" are independent entries.
    public Page<MovieResponse> findAllPaged(int page, int size, String sortBy, String direction) {
        Sort sort = direction.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        return movieRepo.findAll(pageable).map(movieMapper::toResponse);
    }

    @Override
    @Cacheable(value = "moviesByGenre", key = "#genere + '-' + #page + '-' + #size")
    // ✅ Composite key: genre + page + size.
    //    e.g. "Action-0-10" and "Drama-0-10" are cached independently.
    public Page<MovieResponse> findByGenere(String genere, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return movieRepo.findByGenere(genere, pageable).map(movieMapper::toResponse);
    }

    @Override
    @Cacheable(value = "moviesByDirector", key = "#director + '-' + #page + '-' + #size")
    // ✅ Composite key: director + page + size.
    //    e.g. "Nolan-0-10" and "Spielberg-0-10" are cached independently.
    public Page<MovieResponse> findByDirector(String director, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return movieRepo.findByDirector(director, pageable).map(movieMapper::toResponse);
    }

    @Override
    @Cacheable(value = "moviesByRating", key = "#rating")
    // ✅ Each minimum rating threshold cached separately.
    //    e.g. findByRatingAbove(7.0) and findByRatingAbove(8.5) are independent.
    public List<MovieResponse> findByRatingAbove(Double rating) {
        return movieRepo.findByRatingGreaterThanEqual(rating)
                .stream().map(movieMapper::toResponse).toList();
    }

    // =========================================================
    // CUSTOM @Query METHODS — read-only (inherited)
    // Manually written JPQL for logic beyond derived query support
    // =========================================================

    @Override
    @Cacheable(value = "moviesByYear", key = "#from + '-' + #to")
    // ✅ Year range pair used as cache key.
    //    e.g. "2000-2010" and "2010-2020" are cached independently.
    public List<MovieResponse> findMoviesBetweenYears(int from, int to) {
        return movieRepo.findMoviesBetweenYears(from, to)
                .stream().map(movieMapper::toResponse).toList();
    }

    @Override
    @Cacheable(value = "moviesByTitle", key = "#title.toLowerCase()")
    // ✅ Lowercase key: "batman" and "Batman" hit the same cache entry.
    public List<MovieResponse> searchByTitle(String title) {
        return movieRepo.findByTitleContainingIgnoreCase(title)
                .stream().map(movieMapper::toResponse).toList();
    }

    @Override
    @Cacheable(value = "topRatedMovies", key = "#minRating")
    // ✅ Each minRating threshold cached separately.
    //    e.g. findTopRated(8.0) and findTopRated(9.0) are independent entries.
    public List<MovieResponse> findTopRated(Double minRating) {
        return movieRepo.findTopRatedMovies(minRating)
                .stream().map(movieMapper::toResponse).toList();
    }
}