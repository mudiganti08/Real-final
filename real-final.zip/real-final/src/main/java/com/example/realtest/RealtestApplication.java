package com.example.realtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@EnableCaching
// ✅ Spring Boot auto-configures SimpleCacheManager (ConcurrentHashMap)
// ✅ Caches are created automatically on first use
// ✅ No extra config class needed when using spring-boot-starter-cache only
public class RealtestApplication {
    public static void main(String[] args) {
        SpringApplication.run(RealtestApplication.class, args);
    }
}