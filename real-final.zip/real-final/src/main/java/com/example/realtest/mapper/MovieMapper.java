package com.example.realtest.mapper;

import com.example.realtest.dto.MovieRequest;
import com.example.realtest.dto.MovieResponse;
import com.example.realtest.entity.Movie;
import org.springframework.stereotype.Component;

@Component
public class MovieMapper {

    public Movie toEntity(MovieRequest request) {
    
        return Movie.builder().title(request.getTitle())
        		.director(request.getDirector())
        		.genere(request.getGenere())
        		.rating(request.getRating())
        		.releaseYear(request.getReleaseYear())
        		.build();
    }

    public MovieResponse toResponse(Movie movie) {
        return MovieResponse.builder()
            .id(movie.getId())
            .title(movie.getTitle())
            .director(movie.getDirector())
            .genere(movie.getGenere())
            .releaseYear(movie.getReleaseYear())
            .rating(movie.getRating())
            .build();
    }
}