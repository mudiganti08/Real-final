package com.example.realtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
